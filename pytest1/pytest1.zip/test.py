import os
import sys
sys.path.append(os.getcwd())
a=1
li=(1,2,3)
if a in li:
    print("OK")